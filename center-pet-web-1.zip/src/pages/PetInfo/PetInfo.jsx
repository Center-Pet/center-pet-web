"use client"

import { useState } from "react"
import "./CardInfo.css"
import CardInfo from "../../components/CardInfo/CardInfo"

export default function PetInfo() {
  const [currentImage, setCurrentImage] = useState(0)

  const petImages = [
    "/assets/teste.jpg",
    "/assets/teste.jpg",
    "/assets/teste.jpg",
    "/assets/teste.jpg",
    "/assets/teste.jpg",
    "/assets/teste.jpg",
    "/assets/teste.jpg",
  ]

  const petInfo = {
    nome: "Procedure",
    genero: "Macho Alpha",
    idade: "2 meses",
    raca: "Sem Raça Definida",
    porte: "Médio",
    vacinado: "Sim",
    castrado: "Sim",
    vermifugado: "Sim",
    condicaoEspecial: "Nenhuma",
    esperando: "2 meses",
    ong: "Adote me",
  }

  const otherPets = [
    {
      id: 1,
      nome: "Cachorro",
      genero: "Macho",
      idade: "3 meses",
      imagem: "/placeholder.svg?height=200&width=200",
    },
    {
      id: 2,
      nome: "Cachorro",
      genero: "Macho",
      idade: "3 meses",
      imagem: "/placeholder.svg?height=200&width=200",
    },
    {
      id: 3,
      nome: "Cachorro",
      genero: "Macho",
      idade: "3 meses",
      imagem: "/placeholder.svg?height=200&width=200",
    },
    {
      id: 4,
      nome: "Cachorro",
      genero: "Macho",
      idade: "3 meses",
      imagem: "/placeholder.svg?height=200&width=200",
    },
    {
      id: 5,
      nome: "Cachorro",
      genero: "Macho",
      idade: "3 meses",
      imagem: "/placeholder.svg?height=200&width=200",
    },
    {
      id: 6,
      nome: "Cachorro",
      genero: "Macho",
      idade: "3 meses",
      imagem: "/placeholder.svg?height=200&width=200",
    },
  ]

  const handleThumbnailClick = (index) => {
    setCurrentImage(index)
  }

  return (
    <div className="pet-info-container">
      <div className="pet-profile-card">
        <div className="pet-main-info">
          <div className="pet-image-container">
            <img src={petImages[currentImage] || "/placeholder.svg"} alt={petInfo.nome} className="pet-main-image" />
            <button className="edit-button">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M16.862 4.487L18.549 6.174L6.349 18.374L4.662 16.687L16.862 4.487Z" fill="currentColor" />
                <path
                  d="M19.513 3.513C18.632 2.632 17.168 2.632 16.287 3.513L3.513 16.287C3.183 16.617 2.954 17.031 2.853 17.483L2.053 21.047C1.979 21.362 2.079 21.691 2.293 21.905C2.507 22.119 2.836 22.219 3.151 22.145L6.715 21.345C7.167 21.244 7.581 21.015 7.911 20.685L20.685 7.911C21.566 7.03 21.566 5.566 20.685 4.685L19.513 3.513Z"
                  fill="currentColor"
                />
              </svg>
            </button>
          </div>

          <div className="pet-details">
            <h2>Conheça {petInfo.nome}</h2>

            <div className="pet-info-grid">
              <div className="info-row">
                <span className="info-label">Gênero:</span>
                <span className="info-value">{petInfo.genero}</span>
              </div>
              <div className="info-row">
                <span className="info-label">Idade:</span>
                <span className="info-value">{petInfo.idade}</span>
              </div>
              <div className="info-row">
                <span className="info-label">Raça:</span>
                <span className="info-value">{petInfo.raca}</span>
              </div>
              <div className="info-row">
                <span className="info-label">Porte:</span>
                <span className="info-value">{petInfo.porte}</span>
              </div>
              <div className="info-row">
                <span className="info-label">Vacinado:</span>
                <span className="info-value">{petInfo.vacinado}</span>
              </div>
              <div className="info-row">
                <span className="info-label">Castrado:</span>
                <span className="info-value">{petInfo.castrado}</span>
              </div>
              <div className="info-row">
                <span className="info-label">Vermifugado:</span>
                <span className="info-value">{petInfo.vermifugado}</span>
              </div>
              <div className="info-row">
                <span className="info-label">Condição Especial:</span>
                <span className="info-value">{petInfo.condicaoEspecial}</span>
              </div>
              <div className="info-row">
                <span className="info-label">Esperando um amigo há:</span>
                <span className="info-value">{petInfo.esperando}</span>
              </div>
              <div className="info-row">
                <span className="info-label">ONG:</span>
                <span className="info-value">{petInfo.ong}</span>
              </div>
            </div>

            <button className="adopt-button">Adotar!</button>
          </div>
        </div>

        <div className="pet-thumbnails">
          {petImages.map((image, index) => (
            <img
              key={index}
              src={image || "/placeholder.svg"}
              alt={`${petInfo.nome} thumbnail ${index + 1}`}
              className={`pet-thumbnail ${currentImage === index ? "active" : ""}`}
              onClick={() => handleThumbnailClick(index)}
            />
          ))}
        </div>
      </div>

      <div className="other-pets-section">
        <div className="section-header">
          <h2>De Uma Olhada Em Outros Pets</h2>
          <button className="see-more-button">Veja mais</button>
        </div>

        <div className="other-pets-grid">
          {otherPets.map((pet) => (
            <CardInfo key={pet.id} nome={pet.nome} genero={pet.genero} idade={pet.idade} imagem={pet.imagem} />
          ))}
        </div>
      </div>
    </div>
  )
}
