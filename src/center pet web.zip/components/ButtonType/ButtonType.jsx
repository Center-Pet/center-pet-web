import React from 'react';
import './ButtonType.css';

const BotaoPersonalizado = ({ children, onClick, bgColor, color }) => {
  return (
    <button
      className="botao-personalizado"
      onClick={onClick}
      style={{ backgroundColor: bgColor,color:color  }} // Define a cor dinamicamente
    >
      {children}
    </button>
  );
};

export default BotaoPersonalizado;